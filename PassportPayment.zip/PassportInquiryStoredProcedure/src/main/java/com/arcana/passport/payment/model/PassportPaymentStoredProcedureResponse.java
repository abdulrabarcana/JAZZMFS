package com.arcana.passport.payment.model;

public class PassportPaymentStoredProcedureResponse {
	
	private String RESPONSE_CODE;

	public String getRESPONSE_CODE() {
		return RESPONSE_CODE;
	}

	public void setRESPONSE_CODE(String rESPONSE_CODE) {
		RESPONSE_CODE = rESPONSE_CODE;
	}
	
	

}
